
public class HelloMonde {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	     System.out.println("[DUT/INFO/S3]");
	     System.out.println("Hello Monde !");
	     System.out.println("depuis Blagnac.");
	}

}
